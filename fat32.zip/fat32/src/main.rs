fn main() {
    // Your program will start here.
    println!("Hello world!");
}